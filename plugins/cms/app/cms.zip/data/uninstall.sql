
--
-- 模型数据 `cmf_cms_model`
--
DROP TABLE `cmf_cms_model`;

--
-- 模型字段数据 `cmf_cms_fields`
--
DROP TABLE `cmf_cms_fields`;

--
-- 栏目数据 `cmf_cms_channel`
--
DROP TABLE `cmf_cms_channel`;

--
-- 文章基础表数据 `cmf_cms_archives`
--
DROP TABLE `cmf_cms_archives`;

--
--	单页表数据 `cmf_cms_page`
--
DROP TABLE `cmf_cms_page`;

--
--	标签数据 `cmf_cms_tags`
--
DROP TABLE `cmf_cms_tags`;

--
-- 文章外表1数据 `cmf_cms_appnews`
--
DROP TABLE `cmf_cms_appnews`;

--
-- 文章外表2数据 `cmf_cms_appproducts`
--
DROP TABLE `cmf_cms_appproducts`;